# Enmienda metodológica 001 de la fase 3

La primera ejecución PostgreSQL se detuvo antes del análisis después de producir 350
filas de resultados. La preparación insertaba cada conjunto mediante lotes de mil
filas parametrizadas y hacía que la carga, que no forma parte de las operaciones
medidas, dominara el tiempo total.

Se sustituyó exclusivamente la preparación por `COPY FROM STDIN` en formato CSV. No se
modificaron motor, semilla, perfiles, escalas, repeticiones, consultas, configuraciones,
variables, exclusiones ni métodos estadísticos. El archivo parcial fue conservado fuera
del conjunto definitivo como `postgres-discarded-slow-loader.jsonl`.

