# COBRIA replication package

Implementación neutral y prueba sintética de rendimiento del artículo COBRIA.

```bash
npm test
npm run pilot
npm run experiment
npm run analyze
```

Los experimentos usan almacenamiento en memoria y datos sintéticos deterministas. Sus
resultados caracterizan esta implementación y esta máquina; no representan directamente
un proveedor NoSQL ni producción.

La fase 2 agrega SQLite persistente, 30 repeticiones, líneas base equivalentes, evaluación
de recuperación/seguridad de IA y análisis longitudinal:

```bash
npm run phase2
```

SQLite permite medir persistencia e índices reales en un archivo local, pero no representa
un motor NoSQL distribuido ni incluye red. La evaluación RAG valida recuperación y
políticas; no utiliza un LLM ni jueces humanos.

La fase 3 replica el núcleo confirmatorio en PostgreSQL 16 mediante TCP local, añade
datos semirrealistas, cinco escenarios de fallo y una frontera económica:

```bash
export COBRIA_POSTGRES_URL='postgresql://usuario:clave@127.0.0.1:55432/cobria'
npm run phase3
```

El servidor debe estar disponible antes de ejecutar. La carga utiliza `COPY`; la ventana
medida incluye consultas, escrituras y reconstrucciones, no la preparación inicial.

Salidas:

- `results/raw/measurements.jsonl`: observaciones inmutables por corrida.
- `results/manifests/`: configuración y hashes.
- `results/processed/summary.csv`: resumen agregado.
- `results/figures/`: gráficos SVG generados sin edición manual.
- `results/tables/`: tablas LaTeX generadas automáticamente.
- `results/phase2/`: raw, manifiestos, efectos pareados y serie longitudinal.
- `results/phase3/`: observaciones PostgreSQL, datos semirrealistas, fallos, efectos
  pareados, análisis económico, tablas y figuras.

## Reproducción limpia

Requisitos para fases 1 y 2: Node.js 24 o posterior y Python 3. La fase 3 también
requiere PostgreSQL 16 accesible mediante TCP.

1. Verifique el hash del protocolo correspondiente.
2. Ejecute `npm run phase2` o `npm run phase3`.
3. Compare los hashes de archivos crudos y manifiestos.
4. Ejecute `python3 scripts/build-release-manifest.py` desde este directorio.

Código bajo licencia MIT. Datos sintéticos y resultados bajo CC0-1.0.
