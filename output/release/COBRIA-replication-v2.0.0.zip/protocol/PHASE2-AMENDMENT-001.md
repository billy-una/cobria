# Enmienda 001 de la fase 2

- Momento: posterior a la primera corrida SQLite y anterior a incorporar cifras al manuscrito.
- Problema 1: B0, B1 y C1 se ejecutaban en orden fijo, lo que podía confundir configuración con calentamiento.
- Corrección: rotación determinista del orden por perfil, escala y repetición; se registra `executionOrder`.
- Problema 2: la escritura B0 se medía después de crear el índice B1, por lo que no representaba una tabla sin índice.
- Corrección: la familia confirmatoria de escritura compara B1 con C1. B0 se conserva únicamente como línea base de escaneo forzado para lectura.
- Decisión: la corrida `sqlite-2026-08-23T06-22-12-484Z` se descarta íntegramente. No se modifican hipótesis, escalas, repeticiones, métricas ni umbrales.
