# COBRIA replication package

Implementación neutral y benchmark sintético del paper COBRIA.

```bash
npm test
npm run pilot
npm run experiment
npm run analyze
```

Los experimentos usan almacenamiento en memoria y datos sintéticos deterministas. Sus
resultados caracterizan esta implementación y esta máquina; no representan directamente
un proveedor NoSQL ni producción.

La fase 2 agrega SQLite persistente, 30 repeticiones, líneas base equivalentes, evaluación
de recuperación/seguridad de IA y análisis longitudinal:

```bash
npm run phase2
```

SQLite permite medir persistencia e índices reales en un archivo local, pero no representa
un motor NoSQL distribuido ni incluye red. La evaluación RAG valida recuperación y
políticas; no utiliza un LLM ni jueces humanos.

Salidas:

- `results/raw/measurements.jsonl`: observaciones inmutables por corrida.
- `results/manifests/`: configuración y hashes.
- `results/processed/summary.csv`: resumen agregado.
- `results/figures/`: gráficos SVG generados sin edición manual.
- `results/tables/`: tablas LaTeX generadas automáticamente.
- `results/phase2/`: raw, manifiestos, efectos pareados y serie longitudinal.

## Reproducción limpia

Requisitos: Node.js 24 o posterior y Python 3. No requiere servicios ni credenciales.

1. Verifique el hash del protocolo de fase 2.
2. Ejecute `npm run phase2`.
3. Compare los hashes de `results/phase2/raw/` y los manifiestos.
4. Ejecute `python3 scripts/build-release-manifest.py` desde este directorio.

Código bajo licencia MIT. Datos sintéticos y resultados bajo CC0-1.0.
